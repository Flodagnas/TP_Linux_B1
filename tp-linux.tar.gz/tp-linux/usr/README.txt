Bravo, vous venez d'ouvrir votre premier fichier depuis un terminal !

La réponse secrète à la question est : "42"
